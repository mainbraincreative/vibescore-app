'use client';

import html2canvas from 'html2canvas';
import { useRef } from 'react';

export default function VibeScoreCard({ vibe }: { vibe: any }) {
  const cardRef = useRef(null);

  const handleDownload = async () => {
    if (!cardRef.current) return;
    const canvas = await html2canvas(cardRef.current);
    const dataUrl = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = 'vibescore.png';
    link.href = dataUrl;
    link.click();
  };

  return (
    <div
      ref={cardRef}
      className="max-w-xl w-full rounded-2xl border border-border p-6 shadow-lg bg-card text-foreground space-y-4 animate-fade-in"
    >
      <div className="text-xl font-bold">
        {vibe.score}/100 — {vibe.label}
      </div>

      <div className="text-3xl font-semibold italic opacity-90">
        “{vibe.pullQuote}”
      </div>

      <p className="text-base">{vibe.summary}</p>

      <div className="space-y-2">
        {vibe.flags?.map((flag: any, idx: number) => (
          <div key={idx} className="text-sm text-red-500 flex items-center gap-2">
            <span>{flag.emoji}</span>
            <span className="font-semibold">{flag.type}</span>
            <span className="text-gray-500">→ {flag.reason}</span>
          </div>
        ))}
      </div>

      <h2 className="text-lg font-bold mt-6">Suggested Replies</h2>

      {['empathetic', 'direct', 'playful'].map((tone) => (
        <div key={tone}>
          <h3 className="font-semibold capitalize text-yellow-600 mt-4 mb-1">{tone}</h3>
          <p>💬 {vibe.replies?.[tone]?.text}</p>
          <p className="text-sm text-gray-500 italic">Why: {vibe.replies?.[tone]?.why}</p>
          <p className="text-sm text-gray-500 italic">Outcome: {vibe.replies?.[tone]?.outcome}</p>
        </div>
      ))}

      <button
        onClick={handleDownload}
        className="mt-4 bg-gradient-to-r from-red-400 via-yellow-300 to-green-400 hover:opacity-90 text-black font-medium py-2 px-4 rounded shadow transition"
      >
        Download / Share
      </button>
    </div>
  );
}