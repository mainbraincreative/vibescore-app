// app/page.tsx

'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function HomePage() {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleAnalyze = async () => {
    if (!input.trim()) return;
    setLoading(true);

    const res = await fetch('/api/vibe/score', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: input }),
    });

    const data = await res.json();

    localStorage.setItem('vibeResult', JSON.stringify(data));
    router.push('/result');
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 bg-white text-black">
      <h1 className="text-3xl font-bold mb-4">VibeScore</h1>
      <textarea
        className="w-full max-w-xl h-60 p-4 border border-gray-300 rounded-lg resize-none"
        placeholder="Paste your conversation here..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button
        onClick={handleAnalyze}
        disabled={loading}
        className="mt-4 px-6 py-2 bg-black text-white rounded-lg hover:bg-gray-800 disabled:opacity-50"
      >
        {loading ? 'Analyzing...' : 'Analyze the Vibe'}
      </button>
    </main>
  );
}
